package com.example.uploadFiles;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UploadFilesApplication {

	public static void main(String[] args) {
		SpringApplication.run(UploadFilesApplication.class, args);
	}

}
