package com.example.uploadFiles;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UploadFilesApplicationTests {

	@Test
	void contextLoads() {
	}

}
